// MODULE UI
// module nay khong lam gi cu the ma chi la tao ra cac class co ban
// va nho cach thuc require module cua zjs de dong thoi require file ui.css
(function(zjs){
	
	//fix de tuong thich voi zjs version 1.0
	if('required' in zjs)
	zjs.required('ui');

})(zjs);